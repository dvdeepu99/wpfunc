package com.example.wallpaperactivity;

import com.example.wallpaperactivity.wpfunc;
import android.app.WallpaperManager;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Random;

public class wallpaperactivity extends AppCompatActivity {
int var0;
    private Button setWallpaperButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setWallpaperButton = findViewById(R.id.setWallpaperButton);
        setWallpaperButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    EditText var2 = (EditText) findViewById(R.id.lol2);
                    int var00 = Integer.parseInt(var2.getText().toString());
                    wpfunc lol = new wpfunc();
                    String xD = null;
                    if (var00 == 2){
                        xD = lol.neon();
                        new DownloadAndSetWallpaperTask().execute(xD);
                    }
                    else if (var00 == 1){
                        xD = lol.abst();
                        new DownloadAndSetWallpaperTask().execute(xD);
                    }
                    else if (var00 == 3){
                        xD = lol.space();
                        new DownloadAndSetWallpaperTask().execute(xD);
                    }
                    else if (var00 == 4){
                        xD = lol.land();
                        new DownloadAndSetWallpaperTask().execute(xD);
                    }
                    else { Toast.makeText(wallpaperactivity.this, "Unknown value", Toast.LENGTH_SHORT).show(); }
            }
        });
    }
        private class DownloadAndSetWallpaperTask extends AsyncTask<String, Void, Bitmap> {

            @Override
            protected Bitmap doInBackground(String... params) {
                String imageUrl = params[0];
                try {
                    URL url = new URL(imageUrl);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setDoInput(true);
                    connection.connect();
                    InputStream input = connection.getInputStream();
                    Bitmap bitmap = BitmapFactory.decodeStream(input);
                    input.close();
                    return bitmap;
                } catch (IOException e) {
                    e.printStackTrace();
                    return null;
                }
            }

            @Override
            protected void onPostExecute(Bitmap result) {
                if (result != null) {
                    setWallpaper(result);
                } else {
                    Toast.makeText(wallpaperactivity.this, "Couldn't download", Toast.LENGTH_SHORT).show();
                }
            }

            private void setWallpaper(Bitmap bitmap) {
                try {
                    WallpaperManager wallpaperManager = WallpaperManager.getInstance(wallpaperactivity.this);
                    wallpaperManager.setBitmap(bitmap);
                        Toast.makeText(wallpaperactivity.this, "Set", Toast.LENGTH_SHORT).show();
                    } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(wallpaperactivity.this, "Unable to Set", Toast.LENGTH_SHORT).show();
                }
            }
        }
}
