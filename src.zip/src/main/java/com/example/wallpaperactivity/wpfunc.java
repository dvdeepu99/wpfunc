package com.example.wallpaperactivity;

import android.app.WallpaperManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Random;

public class wpfunc {
    public String neon(){
        String[] strneon = new String[10];
        strneon[0] = "https://w.forfun.com/fetch/32/32e4ac93987df7dd32f8ef6963fe70be.jpeg";
        strneon[1] = "https://wallpaperaccess.com/full/5990721.jpg";
        strneon[2] = "https://w.forfun.com/fetch/32/324e3921ae2fd444041d6849310becf7.jpeg";
        strneon[3] = "https://wallpaper.dog/large/17211400.jpg";
        strneon[4] = "https://images.unsplash.com/photo-1624762281298-da485f136371?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxjb2xsZWN0aW9uLXBhZ2V8MXw0OTg2OTc5fHxlbnwwfHx8fHw%3D&w=1000&q=80";
        strneon[5] = "https://e1.pxfuel.com/desktop-wallpaper/176/459/desktop-wallpaper-synthwave-city-neon-phone.jpg";
        strneon[6] = "https://wallpaperaccess.com/full/639702.jpg";
        strneon[7] = "https://wallpaperaccess.com/full/1528018.jpg";
        strneon[8] = "https://e0.pxfuel.com/wallpapers/273/977/desktop-wallpaper-led-mask-neon-hacker.jpg";
        strneon[9] = "https://wallpaperaccess.com/full/3602083.jpg";
        Random random = new Random();
        int number = random.nextInt(10);
        String imageUrl = strneon[number];
        return imageUrl;
        }
    public String abst(){
        String[] strabs = new String[10];
        strabs[0] = "https://wallpaperaccess.com/full/2037140.jpg";
        strabs[1] = "https://images.hdqwalls.com/download/digital-color-shapes-4k-vw-1125x2436.jpg";
        strabs[2] = "https://wallpaperaccess.com/full/4631521.jpg";
        strabs[3] = "https://i0.wp.com/www.3wallpapers.fr/wp-content/uploads/2020/01/iPhone-wallpapers-abstract-glass-dark-purple.png";
        strabs[4] = "https://i0.wp.com/www.3wallpapers.fr/wp-content/uploads/2020/10/iPhone-wallpapers-abstract-colors-pink-scaled.jpg";
        strabs[5] = "https://www.3wallpapers.fr/wp-content/uploads/2021/06/iPhone-wallpapers-abstract-pattern-blue.jpg";
        strabs[6] = "https://i0.wp.com/www.3wallpapers.fr/wp-content/uploads/2020/04/iPhone-wallpapers-abstract-painting-blue-pink.png";
        strabs[7] = "https://wallpaperaccess.com/full/1650422.jpg";
        strabs[8] = "https://i.pinimg.com/736x/18/5e/78/185e78dcde67752adc2c4f63eac2a911.jpg";
        strabs[9] = "https://cdn.wallpapersafari.com/63/65/txT7DA.jpg";
        Random random = new Random();
        int number = random.nextInt(10);
        String imageUrl = strabs[number];
        return imageUrl;
        }

    public String space() {
        String[] strspc = new String[10];
        strspc[0] = "https://wallpapers.com/images/hd/hd-space-galaxy-portrait-259u3zufsvb7788l.jpg";
        strspc[1] = "https://i.pinimg.com/1200x/b6/d4/78/b6d47821cd42a69d8e49374b510c9782.jpg";
        strspc[2] = "https://w0.peakpx.com/wallpaper/551/690/HD-wallpaper-space-vertical-nebula-portrait-display-astronomy-universe.jpg";
        strspc[3] = "https://c4.wallpaperflare.com/wallpaper/5/168/847/portrait-display-cgi-planet-milky-way-wallpaper-preview.jpg";
        strspc[4] = "https://wallpapercave.com/wp/wp7743419.jpg";
        strspc[5] = "https://i.pinimg.com/originals/98/29/b8/9829b86a4aacddbfb950c1ca0be33536.jpg";
        strspc[6] = "https://wallpaperaccess.com/full/819305.jpg";
        strspc[7] = "https://w0.peakpx.com/wallpaper/101/280/HD-wallpaper-space-galaxy-vertical-portrait-display.jpg";
        strspc[8] = "https://img1.wallspic.com/crops/0/4/2/7/5/157240/157240-milky_way-galaxy-astrophotography-star-brown-1080x2340.jpg";
        strspc[9] = "https://c4.wallpaperflare.com/wallpaper/77/868/1020/space-galaxy-vertical-portrait-display-wallpaper-preview.jpg";
        Random random = new Random();
        int number = random.nextInt(10);
        String imageUrl = strspc[number];
        return imageUrl;
    }
    public String land() {
        String[] strlnd = new String[5];
        strlnd[0] = "https://wallpapercave.com/wp/wp9392330.jpg";
        strlnd[1] = "https://i.pinimg.com/736x/f4/9d/a1/f49da126483b4aef7dc1944cdfe68a8a.jpg";
        strlnd[2] = "https://w0.peakpx.com/wallpaper/686/594/HD-wallpaper-mist-landscape-forest-road-portrait-display-nature.jpg";
        strlnd[3] = "https://wallpapercave.com/wp/wp5163364.jpg";
        strlnd[4] = "https://pbs.twimg.com/media/EqwB9nhXYAEWFqA.jpg";
        Random random = new Random();
        int number = random.nextInt(5);
        String imageUrl = strlnd[number];
        return imageUrl;
    }
}